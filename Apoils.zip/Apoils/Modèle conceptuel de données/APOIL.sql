DROP DATABASE IF EXISTS apoils;
CREATE DATABASE apoils;
USE apoils;
/*
DROP TABLE IF EXISTS Animal;
DROP TABLE IF EXISTS Espece;
DROP TABLE IF EXISTS Race ;
DROP TABLE IF EXISTS Utilisateur;
DROP TABLE IF EXISTS Agir;
*/



CREATE TABLE Utilisateur(
	id VARCHAR(50) PRIMARY KEY,
    nom VARCHAR(20),
    prenom VARCHAR(20),
    ddn date,
    mail VARCHAR(20),
    telephone CHAR(10),
    login_u VARCHAR(20),
    mdp VARCHAR(50),
    photo_id VARCHAR(100)
);


SELECT * FROM Animal;

CREATE TABLE Espece(
	id INT PRIMARY KEY,
    nom VARCHAR(50)
);

CREATE TABLE Race(
	id INT PRIMARY KEY,
	nom_r VARCHAR(50),
	idEspece INT,
    particularite_physique VARCHAR(90),
    esperance_vie INT,
    education VARCHAR(90),
    activite_physique VARCHAR(200),
    entretien_hygiene VARCHAR(200),
    res_race text, /* résumé sur la ce ra	*/
    FOREIGN KEY fk_idEspece(idEspece) REFERENCES Espece(id)
);

CREATE TABLE Animal(
	id VARCHAR(50) PRIMARY KEY NOT NULL,
    nom VARCHAR(50) NOT NULL,
    idEspece INT NOT NULL,
    idRace INT NOT NULL,
    age INT NOT NULL,
    adjectif VARCHAR(50) NOT NULL,
    prix INT NOT NULL,
	etat_sante VARCHAR(50) NOT NULL,
    photo text NOT NULL,
    idUti VARCHAR(50) NOT NULL,
   
    FOREIGN KEY fk_iduti(idUti) REFERENCES Utilisateur(id),
    FOREIGN KEY fk_idrace(idRace) REFERENCES Race(id),
	FOREIGN KEY fk_idesp(idEspece) REFERENCES Espece(id)
);

SELECT * FROM Animal;

INSERT INTO Utilisateur VALUES(12,"Henry", "Bizou", '2002-09-01',"didier@gmail.com","0660504522","benjamindu29","vivelesanimaux","image.jpg");
INSERT INTO Utilisateur VALUES(48,"Douglas", "Le Normand", '1995-02-10',"prout@gmail.com","0760504522","inesdu56","monmdp","image.jpg");
INSERT INTO Utilisateur VALUES(77,"Doman", "Le Norvégien", '1998-12-25',"prut@gmail.com","076050522","haridu15","monmdp","image.jpg");
INSERT INTO Espece VALUES (01,"Chien");
INSERT INTO Espece VALUES (02,"Chat");
INSERT INTO Espece VALUES (03,"Oiseau");
INSERT INTO Espece VALUES (04,"Dinosaure");

INSERT INTO Race VALUES (01,"Berger allemand",1,"Poilu", 15, "bonne", "bcp", "longtemps","fegre");
INSERT INTO Race VALUES (02,"Berger angalis",1,"Gros", 150, "bonne", "bcp", "longtemps", "vfre");
INSERT INTO Race VALUES (07,"Rotweiler",1,"Gros", 150, "bonne", "bcp", "longtemps", "frge");
INSERT INTO Race VALUES (03,"Chat americain",2,"Gros", 150, "bonne", "bcp", "longtemps", "fdez");

SELECT * FROM Animal;


SELECT R.nom FROM Race R, Espece E WHERE R.idEspece=E.id AND E.nom="Chien";



