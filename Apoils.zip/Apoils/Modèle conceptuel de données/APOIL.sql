DROP DATABASE IF EXISTS apoils;
CREATE DATABASE apoils;
USE apoils;

/*
DROP TABLE IF EXISTS Animal;
DROP TABLE IF EXISTS Espece;
DROP TABLE IF EXISTS Race ;
DROP TABLE IF EXISTS Utilisateur;
DROP TABLE IF EXISTS Agir;
*/



CREATE TABLE Utilisateur(
	id VARCHAR(70) PRIMARY KEY,
    nom VARCHAR(70),
    prenom VARCHAR(70),
    ddn date,
    mail VARCHAR(70),
    telephone CHAR(11),
    login_u VARCHAR(70),
    mdp VARCHAR(70),
    photo_id VARCHAR(150),
    valide INT,
    administrateur INT
);




CREATE TABLE Espece(
	id INT PRIMARY KEY,
    nom VARCHAR(50)
);

CREATE TABLE Race(
	id INT PRIMARY KEY,
	nom_r VARCHAR(50),
	idEspece INT,
    particularite_physique VARCHAR(90),
    esperance_vie INT,
    education VARCHAR(90),
    activite_physique VARCHAR(200),
    entretien_hygiene VARCHAR(200),
    res_race text, /* résumé sur la ce race	*/
    FOREIGN KEY fk_idEspece(idEspece) REFERENCES Espece(id)
);

CREATE TABLE Animal(
	id VARCHAR(50) PRIMARY KEY NOT NULL,
    nom VARCHAR(50) NOT NULL,
    idEspece INT NOT NULL,
    idRace INT NOT NULL,
    age INT NOT NULL,
    adjectif VARCHAR(50) NOT NULL,
	etat_sante VARCHAR(50) NOT NULL,
    photo text NOT NULL,
    idUti VARCHAR(50) NOT NULL,
   
    FOREIGN KEY fk_iduti(idUti) REFERENCES Utilisateur(id),
    FOREIGN KEY fk_idrace(idRace) REFERENCES Race(id),
	FOREIGN KEY fk_idesp(idEspece) REFERENCES Espece(id)
);

/**/

SELECT * FROM Utilisateur;




INSERT INTO Espece VALUES (01,"Chien");
INSERT INTO Espece VALUES (02,"Chat");
INSERT INTO Espece VALUES (03,"Oiseau");
INSERT INTO Espece VALUES (04,"Dinosaure");

INSERT INTO Race VALUES (01,"Berger allemand",1,"Poilu", 15, "bonne", "bcp", "longtemps","fegre");
INSERT INTO Race VALUES (02,"Berger angalis",1,"Gros", 150, "bonne", "bcp", "longtemps", "vfre");
INSERT INTO Race VALUES (07,"Rotweiler",1,"Gros", 150, "bonne", "bcp", "longtemps", "frge");
INSERT INTO Race VALUES (03,"Chat americain",2,"Gros", 150, "bonne", "bcp", "longtemps", "fdez");
INSERT INTO Race VALUES (04,"Colibri",3,"Gros", 150, "bonne", "bcp", "longtemps", "ça vole bien");
INSERT INTO Race VALUES (05,"Aigle Royal",3,"Gros", 150, "bonne", "bcp", "longtemps", "Il chasse très bien");
INSERT INTO Race VALUES (06,"T-REX Royal",4,"Gros", 150, "bonne", "bcp", "longtemps", "Oui oui, ils existent encore!");

SELECT * FROM Race;

SELECT R.nom FROM Race R, Espece E WHERE R.idEspece=E.id AND E.nom="Chien";



