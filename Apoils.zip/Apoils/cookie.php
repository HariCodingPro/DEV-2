<!DOCTYPE html>
<html>

    <?php include_once("head.php"); ?>

    <body>

        <?php include_once("header.php"); ?>

        <main>
            <div style="text-align:center;">
                <h1>Cookies</h1>
                <p font size: 100px> Un animal adopté, un cookie offert</p>
            
            <img src="images/cookies.jpeg"></div>
        </main>

        <?php include_once("footer.php"); ?> 

    </body>

</html>
        