<!DOCTYPE html>
<html>
    <?php include_once("head.php"); 
       if($_SESSION["connexion"]==0){
        header('Location: connexion.php');
       }
    ?>
    <body>
        <?php include_once("header.php"); 
        $tab_info = array();
        ?>
           
        <?php 
            if(isset($_POST["fsubmit"])&&empty($tab_info)){
                function generate_id(){
                    $aid='';
                    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
                    $randomString = '';
                
                    for ($a = 0; $a < 5; $a++) {
                        $index = rand(0, strlen($characters) - 1);
                        $randomString .= $characters[$index];
                    }
            
                    $aid="ANI-".time().$randomString;
            
                    return $aid;
                
                }
            
                
                
                $tab_info["id"]="'".generate_id()."'";
                $tab_info["nom"]="'".$_POST["fnom_a"]."'";
                $tab_info["idEspece"]=0;
                $tab_info["idRace"]=1;
                $tab_info["age"]=intval($_POST["fage_a"],10);
                $tab_info["adjectif"]="'".$_POST["fadj"]."'";
                $tab_info["prix"]=intval($_POST["fprix"],10);
                $tab_info["etat"]="'".$_POST["fetat"]."'";
                /*Gérer les images*/
            
                $nom_dossier=substr($tab_info["id"], 1, -1);
            
                $tab_info["photo"]="'./images/db_images/".$_POST["fesp"]."/".$nom_dossier."'";
                mkdir("./images/db_images/".$_POST["fesp"]."/".$nom_dossier."");
            
                /*Recuperer image puis mettre dans le dossier ! */
            
                
            
                /*Récupérer l'id uti */
                /*UN VARCHAR MTN*/
                $tab_info["idUti"]="'".$_SESSION["idUser"]."'";

              
            
                /*Creer dossier avec id animal dans la bonne espèce*/
                
                /*Requête pour trouver le nom de l'espèce*/
                $sql = "SELECT id FROM Espece WHERE nom='".$_POST["fesp"]."'";
            
                $result = $conn->query($sql);
                $i=0;
                if ($result->num_rows > 0) {
            
                    while($row = $result->fetch_assoc()) {
                        $tab_info["idEspece"]=intval($row["id"], 10);
                        
                    }
                } 
            
                else {
                    echo "0 résultat";
                }
            
            
                /*Requête pour trouver le nom de la race*/
                $sql = "SELECT id FROM Race WHERE nom_r='".$_POST["frace"]."'";
            
                $result = $conn->query($sql);
                $i=0;
                if ($result->num_rows> 0) {
            
                    while($row = $result->fetch_assoc()) {
                        $tab_info["idRace"]=intval($row["id"], 10);
                    }
                } 
            
                else {
                    echo "0 résultat pour la race";
                }
            
            
            
                /*var_dump($tab_info);*/
            
                $for_sql=implode(',', $tab_info);
            
                echo $for_sql;
              
                $sql = "INSERT INTO Animal VALUE(".$for_sql.")";
            
                $result = $conn->query($sql);
                
            
                if ($result == TRUE) {
                    echo "\nNew data added perfectly !";
                } 
            
                else {
                    echo "Error: <br>" . $conn->error;
                    
                }

                header("Location: moncompte.php");
            
            }
        ?>

        <main>
            <h1 style="text-align:center;">Créer mon annonce</h1>
        
            <div id="form_annonce">
                <form id="form" name="form_add_ani" method="POST" onsubmit="return valider_annonce()"> 
                    <h2>Parlez-nous un peu de vous</h2>
                    <label for="fnom">Nom  </label><br>
                    <input type="text" id="fnom" name="fnom"><br><br>

                    <label for="fprenom">Prénom  </label><br>
                    <input type="text" id="fprenom" name="fprenom"><br><br>

                    <label for="fddn">Date de naissance  </label><br>
                    <input type="date" id="fddn" name="fddn"><br><br>

                    <label for="fmail">Mail  </label><br>
                    <input type="text" id="fmail" name="fmail"><br><br>

                    <label for="ftel">Téléphone  </label>
                    <i class="fas fa-phone"></i><br>
                    <input type="text" id="ftel" name="ftel"><br><br>

                   

                    <h2>Informations sur l'animal</h2>

                    <label for="fnom_a">Nom  </label><br>
                    <input type="text" id="fnom_a" name="fnom_a"><br><br>

                    <label for="fage_a">Age  </label><br>
                    <input type="text" id="fage_a" name="fage_a"><br><br>

                    <label for="fesp">Espèce</label><br>

                    <br>
                    
                    <div onclick="pour_race(this)">
                    <select id="fesp" name="fesp">
                        <option>Vide</option>
                        <?php
                            $sql = "SELECT * FROM Espece";
                            $result = $conn->query($sql);

                            if ($result->num_rows > 0) {
                            // output data of each row
                                while($row = $result->fetch_assoc()) {
                                    echo "
                                    <option value='".$row["nom"]."'>
                                        ".$row["nom"]."
                                    </option>
                                    ";
                                }
                            } 

                            else {
                                echo "Aucune espece disponible";
                            }

                            /*PUIS AJAX POUR RACE*/
                        ?>
                    </select></div><br><br>

                            

                    <label for="frace">Race</label><br><br>
                    
                    <select type="text" id="frace" name="frace">
                    <option>Vide</option>
                    </select>    
                    <br><br>

                
                    <label for="fphoto">Photo</label>
                    <i class="fas fa-image"></i><br><br>
                    <input type="file" id="fphoto" name="fphoto">
                    <br><br>

                    <label for="fprix">Prix</label><br>
                    <input type="text" id="fprix" name="fprix"> <span>€</span>
                    <br><br>

                    <!--mettre un select -->
                    <label for="fetat">Etat de santé</label><br>
                    <input type="text" id="fetat" name="fetat"><br><br>

                    <label for="fadj">Un petit mot pour décrire votre animal ?</label><br>
                    <input type="text" id="fadj" name="fadj"><br><br>
                    

                    <!--CHANGER TYPE EN SUBMIT-->
                    <input type="submit" id="fsubmit" name="fsubmit" value="Envoyer" >
                </form>

                <div id="side_img_annonce">
                    <img src="images/annonce.png">
                </div>
            </div>
        </main>

        <?php include_once("footer.php"); 
        
        ?>
    </body>
</html>