<header>
            <div id="menu" name="menu">
                <div id="croixxx">
                    <i class="fas fa-times" style="color: #ffffff;" type="button"  style="color:white;" onclick="derouler()"></i>
                </div>
                <ul>
                    <li><a href="index.php"><input class="sidemenu_button" type="button" value="Accueil"></a></li>
                    <li><a href="adoptions.php"><input class="sidemenu_button" type="button" value="Adopter"></a></li>
                    <li><a href="creerannonce.php"><input class="sidemenu_button" type="button" value="Creer mon annonce"></a></li>
                    <li><a href="liste_description.php"><input class="sidemenu_button" type="button" value="Decouvrir nos animaux"></a></li>
                    <li><a href="apropos.php"><input class="sidemenu_button" type="button" value="Qui sommes nous ?"></a></li>
                </ul>
            </div>

            <div id="gray_bg" name="gray_bg" onclick="derouler()">
                
            </div>

            <div id="div_bouton_menu" name="div_bouton_menu" onclick="derouler()">
                <div id="sous_div_menu" name="sous_div_menu">
                    <div id="details" name="details">
                        <div class="explore_but1"></div>
                        <div class="explore_but2"></div>
                        <div class="explore_but3"></div>
                    </div>    
                    <p>Menu</p> 
                </div>
            </div>
           
            <div id="logo" name="logo">
                <a href="index.php" title="Aller à l'accueil">
                <img src="images/logo.jpg" width="100px" height="100%">
                </a>
            </div>

            <nav id="nav_bar" name="nav_bar">
                <ul>
                    <li><a href="index.php"><input type="button" value="Accueil" class="nav_explore"></a></li>
                    <li><a href="liste_description.php"><input type="button" value="Nos animaux" class="nav_explore"></a></li>
                    <li><a href="apropos.php"><input type="button" value="A propos" class="nav_explore"></a></li>
                </ul>
            </nav>

            <div id="fav_cpt" name="fav_cpt">
                <ul>
                    <li><a style='font-size:24px' class='fa' href="favoris.php" title="Favoris">&#xf004;</a></li> <!--COEUR-->
                    <li><a style='font-size:24px' class='fas' href="compte.php" title="Compte" >&#xf406;</a></li> <!--Bonhomme-->
                </ul>
            </div>

        </header>