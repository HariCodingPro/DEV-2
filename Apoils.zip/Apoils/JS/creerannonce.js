function pour_race(x){
    var val=document.getElementById("fesp").value;
    if(val != "Vide"){
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("frace").innerHTML = this.responseText;
            }
        };
        
        xmlhttp.open("GET", "PHP/appelrace.php?e=" + val, true);
        xmlhttp.send();
    }
  
}

/*FAIRE LES VERIF + vert quand tout est bon*/
function valider_annonce(){

    var fnom_a = document.getElementById("fnom_a");
    var fage_a = document.getElementById("fage_a");
    var fesp = document.getElementById("fesp");
    var frace = document.getElementById("frace");
    var fphoto = document.getElementById("fphoto");
    var fprix = document.getElementById("fprix");
    var fetat = document.getElementById("fetat");
    var fadj = document.getElementById("fadj");
    var valide=1;

    if (fnom_a.value == ""){ 
        fnom_a.style.borderBottom= "1px solid red";
    }else{

        fnom_a.style.borderBottom = "1px solid black"; 
    }

    if (fage_a.value==""){
        fage_a.style.borderBottom = "1px solid red";
    }else{
        fage_a.style.borderBottom = "1px solid black";
    }

    if(fesp.value=="Vide"){
        fesp.style.border = "1px solid red";
    }else{
        fesp.style.border = "1px solid black";
    }

    if(frace.value=="Vide"){
        frace.style.border = "1px solid black";
    }else{
        frace.style.border = "1px solid black";
    }

    if(fphoto.value==""){
        fphoto.style.borderBottom = "1px solid red";
    }else{ 
        fphoto.style.borderBottom = "1px solid black";
    }


    if(fprix.value==""){
        fprix.style.borderBottom = "1px solid red";
    }else{
       
        fprix.style.borderBottom = "1px solid black";
    }

    if(fetat.value==""){
        fetat.style.borderBottom = "1px solid red";
    }else{
        fetat.style.borderBottom = "1px solid black";
    }

    if(fadj.value==""){
        fadj.style.borderBottom = "1px solid red";
    }else{
        fadj.style.borderBottom = "1px solid black"; 
    }           
                

/*
   if(valide == 0){
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById("frace").innerHTML = this.responseText;
        }
    };
    
    xmlhttp.open("GET", "PHP/ajout_bdd_animal.php?nom="+nom+"&age="+age+"&esp="+Esp+"&race="+Race+"&prix="+prix+"&etat="+etat+"&adj="+adj+"&img="+"./images/db_images/Chien/didiou.jpg", true);
    xmlhttp.send();

    }

*/

}