<?php 
    session_start();
    $dir="./target/";
 

    if(isset($_FILES["photo_up"])){

        for($i=0;$i<count($_FILES["photo_up"]["name"]);$i++){

            $file=$dir.$_FILES["photo_up"]["name"][$i];

            if (move_uploaded_file($_FILES['photo_up']['tmp_name'][$i], $file)) {
                        echo "File is valid, and was successfully uploaded.\n";
                    } 
            else {
                echo "Possible file upload attack!\n";
            }
            
            echo 'Here is some more debugging info:';
            print_r($_FILES);
        }

        
    }


?>

<!DOCTYPE html>
<html>
    <head>
        <script>
           
        </script>
    </head>
   
    <body>
        <form action="form.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="MAX_FILE_SIZE" value="300000"/>
            <input type="file" id="photo_up" name="photo_up[]" multiple accept=".png, .jpg, .jpeg" required><br>
            <input type="submit" value="Téléverser">
        </form>

    </body>




</html>
