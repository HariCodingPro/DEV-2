<!--
    LE CSS de ce fichier est dans compte.css et creerannonce.css
 -->

<?php
  

?>

<!DOCTYPE html>
<html>
    <?php include_once("head.php"); ?>
    <body>
        <?php include_once("header.php"); ?>
            <div id="images_connexion">
                <h1 style="text-align:center; color:white;">Connexion</h1>
                    <div id="formannonce">
                        <form id="forms" method="post">
                            <label for="blogin" style="text-align:center;">Identifiant</label><br>
                            <input type="text" id="blogin"><br><br>

                            <label for="bmdp" style="text-align:center;">Mot de passe</label><br>
                            <input type="password" id="bmdp"><br><br>

                            <a href="creationcompte.php" id="un">Je n'ai pas de compte</a><br><br><br>

                            <input type="submit" class="submit_co" name="submit_co_but" onclick="connexion()">
                        </form>
                    </div>
            </div>
        
        <?php include_once("footer.php"); ?> 
    </body>
</html>
        