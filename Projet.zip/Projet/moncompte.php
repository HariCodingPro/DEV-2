<!DOCTYPE html>
<html>
    <?php include_once("head.php"); 
    
       
        if(isset($_SESSION["connexion"])){
            if($_SESSION["connexion"]==0){
               header('Location: index.php');  
            }

            else if(isset($_POST["logout_but"])&&$_SESSION["connexion"]==1){
                $_SESSION["connexion"]=0;
                header('Location: index.php');  
            }

            
           
        }

        else{
            header('Location: index.php');  
        }
    ?>
    <body>
        <?php include_once("header.php"); ?>

        <p>METTRE LES ANNONCES possédées</p>
        <main>
            <div style="text-align:center;">
                <h1>Mon profil</h1>
            </div>
           

            <div class="alignement">
                <div class="formsannonce">
                            <form class="forms">

                                <label class="titre_compte">Nom  </label><br>
                                <p>Le Guellec</p><br><br>

                                <label class="titre_compte">Prénom  </label><br>
                                <p>Benjamin</p><br><br>

                                <label class="titre_compte">Date de naissance  </label><br>
                                <p>14 mars 2001</p><br><br>

                                <label class="titre_compte">Mail  </label><br>
                                <p>benjaminleguellec@gmail.com</p><br><br>

                                <label class="titre_compte">Téléphone  </label>
                                <i class="fas fa-phone"></i><br>
                                <p>06 95 08 35 07</p><br><br>
                            </form>
                </div>
                <div class="formsannonce">
                            <form class="forms">
                               
                            
                                <label class="titre_compte">Identifiant</label><br>
                                <p>benjamin</p><br><br>

                                <label class="titre_compte">Mot de passe</label><br>
                                <p>motdepasse</p><br><br>
                            </form>
                </div>
                <div class="formsannonce">
                    <div class="alignements">
                                <img class="moncompte_image" src="images/default.jpg"><br><br>
                                <input type="file" name="image">
                                <input type="submit" id="bouton_compte" value="Changer de photo de profil">
                                
                    </div>
                                


                </div>
            </div>
            

                <div class="formannonce">
                    <form class="forms" method="post">
                        <a href="index.php" class="un">Accueil</a><br><br><br>
                        <a href="adoption.php" class="un">Découvrir nos animaux</a><br><br><br>
                        <input type="submit" id="logout_but" name="logout_but" value="Déconnexion">
                    </form>
                
                </div>
            




        
        </main>

        <?php include_once("footer.php"); ?> 
    </body>
</html>