<!DOCTYPE html>
<html>
    <?php include_once("head.php"); ?>
    <body>
        <?php include_once("header.php"); ?>
        <?php include_once("footer.php"); ?>
    </body>
</html>