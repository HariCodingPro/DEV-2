

<head>
    <title>A poils !</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="./CSS/header.css">
    <link rel="stylesheet" href="./CSS/accueil.css">
    <link rel="stylesheet" href="./CSS/adoptions.css">
    <link rel="stylesheet" href="./CSS/creerannonce.css">
    <link rel="stylesheet" href="./CSS/compte.css">
    <link rel="stylesheet" href="./CSS/moncompte.css">
    <link rel="stylesheet" href="./CSS/apropos.css">
    <link rel="stylesheet" href="./CSS/description.css">
    <link rel="stylesheet" href="./CSS/footer.css">
    <link rel="stylesheet" href="./CSS/liste_description.css">
    <link rel="stylesheet" href="./CSS/contacteznous.css">
    <link rel="stylesheet" href="./CSS/favoris.css">
    <link rel="stylesheet" href="./CSS/pageanimal.css">
    <link rel="stylesheet" href="./CSS/adopter.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.13.0/css/all.css"/>
    <link rel="stylesheet" href="https://kit.fontawesome.com/3973c994c7.css" crossorigin="anonymous">
    <script src="JS/header.js"></script>
    <script src="JS/creerannonce.js"></script>
    <script src="JS/connexion.js"></script>

</head>

