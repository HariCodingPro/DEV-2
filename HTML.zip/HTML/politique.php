<!DOCTYPE html>
<html>

    <head>
        <title>A poils !</title>
        <meta charset="utf-8">
        <link rel="stylesheet" href="./CSS/header.css">
        <link rel="stylesheet" href="./CSS/accueil.css">
        <link rel="stylesheet" href="./CSS/adoptions.css">
        <link rel="stylesheet" href="./CSS/creerannonce.css">
        <link rel="stylesheet" href="./CSS/compte.css">
        <link rel="stylesheet" href="./CSS/moncompte.css">
        <link rel="stylesheet" href="./CSS/apropos.css">
        <link rel="stylesheet" href="./CSS/description.css">
        <link rel="stylesheet" href="./CSS/footer.css">
        <link rel="stylesheet" href="./CSS/liste_description.css">
        <link rel="stylesheet" href="./CSS/contacteznous.css">
        <link rel="stylesheet" href="./CSS/favoris.css">
        <link rel="stylesheet" href="./CSS/pageanimal.css">
        <link rel="stylesheet" href="./CSS/adopter.css">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.13.0/css/all.css"/>
        <link rel="stylesheet" href="https://kit.fontawesome.com/3973c994c7.css" crossorigin="anonymous">
        <script src="JS/header.js"></script>
        <script src="JS/creerannonce.js"></script>
        <script src="JS/connexion.js"></script>

    </head>

    <body>

            <header>
                <div id="menu" name="menu">
                    <input id="fermer_menu" type="button" value="fermer" onclick="derouler()">
                    <ul>
                        <li><a href="index.php"><input class="sidemenu_button" type="button" value="Accueil"></a></li>
                        <li><a href="adoptions.php"><input class="sidemenu_button" type="button" value="Adopter"></a></li>
                        <li><a href="creerannonce.php"><input class="sidemenu_button" type="button" value="Creer mon annonce"></a></li>
                        <li><a href="liste_description.php"><input class="sidemenu_button" type="button" value="Decouvrir nos animaux"></a></li>
                        <li><a href="apropos.php"><input class="sidemenu_button" type="button" value="Qui sommes nous ?"></a></li>
                    </ul>
                </div>

                <div id="gray_bg" name="gray_bg" onclick="derouler()">
                    
                </div>

                <div id="div_bouton_menu" name="div_bouton_menu" onclick="derouler()">
                    <div id="sous_div_menu" name="sous_div_menu">
                        <div id="details" name="details">
                            <div class="explore_but1"></div>
                            <div class="explore_but2"></div>
                            <div class="explore_but3"></div>
                        </div>    
                        <p>Menu</p> 
                    </div>
                </div>
            
                <div id="logo" name="logo">
                    <a href="index.php" title="Aller à l'accueil">
                    <img src="images/logo.jpg" width="100px" height="100%">
                    </a>
                </div>

                <nav id="nav_bar" name="nav_bar">
                    <ul>
                        <li><a href="index.php"><input type="button" value="Accueil" class="nav_explore"></a></li>
                        <li><a href="liste_description.php"><input type="button" value="Nos animaux" class="nav_explore"></a></li>
                        <li><a href="apropos.php"><input type="button" value="A propos" class="nav_explore"></a></li>
                    </ul>
                </nav>

                <div id="fav_cpt" name="fav_cpt">
                    <ul>
                        <li><a style='font-size:24px' class='fa' href="favoris.php" title="Favoris">&#xf004;</a></li> <!--COEUR-->
                        <li><a style='font-size:24px' class='fas' href="compte.php" title="Compte" >&#xf406;</a></li> <!--Bonhomme-->
                    </ul>
                </div>

            </header>

        <main>
            <div style="text-align:center;">
                <h1>Politique de confidentialité</h1>
            </div>
                <div style="text-align:justify; margin: 5em;">
                    <p>A Poils accorde en permanence une attention aux données de nos Utilisateurs. Nous pouvons ainsi être amenés à modifier, compléter ou mettre à jour périodiquement la Politique de protection des données personnelles. Nous pourrons aussi apporter des modifications nécessaires afin de respecter les changements de la législation et règlementation en vigueur. Dans la mesure du possible, nous vous notifierons tout changement important. Nous vous encourageons toutefois à consulter régulièrement la dernière version en vigueur.</p>
                    <h3>Quelles données personnelles sont collectées ?</h3>
                    <p>Dans le cadre des traitements de données à caractère personnel, nous sommes amenés à collecter et à traiter les données suivantes :
                        <ul>
                            <li>vos noms et prénoms</li>
                            <li>vos coordonnées (adresse postale, adresse email, numéro de téléphone)</li>
                        </ul>
                    </p>
                </div>
                <div style="text-align:justify; margin: 5em;">
                    <h3>Quelles sont les finalités et les bases juridiques des traitements ?</h3>
                    <p>Certains traitements mis en œuvre par OpenClassrooms sont nécessaires à l’exécution d’un contrat auquel l’Utilisateur est partie ou à l’exécution des mesures précontractuelles prises à la demande de celui-ci. Il en est ainsi notamment des traitements qui poursuivent les finalités suivantes :
                        <ul>
                            <li>gestion des cookies non soumis au consentement</li>
                            <li>gestion des demandes d’information et de réclamations</li>
                            <li>réalisation de statistiques et d’enquêtes des Utilisateurs</li>
                        </ul>
                    </p>
                </div>
                <div style="text-align:justify; margin: 5em;">
                    <h3>Comment sont protégées vos données personnelles ?</h3>
                    <p>A Poils applique les mesures de sécurité technologiques et organisationnelles généralement reconnues afin que les données à caractère personnel recueillies ne soient, ni perdues, ni détournées, ni consultées, ni modifiées ni divulguées par des tiers non autorisés sauf si la communication de ces données est imposée par la réglementation en vigueur, notamment à la requête d'une autorité judiciaire, de police, de gendarmerie ou de toute autre autorité habilitée par la loi.</p>
                    <p>La sécurité des données personnelles dépend également des Utilisateurs. Les Utilisateurs qui sont membres d'A Poils s'engagent à conserver la confidentialité de leur identifiant et de leur mot de passe. Les membres s'engagent également à ne pas partager leur compte et à déclarer à A Poils toute utilisation non autorisée dudit compte dès lors qu'ils en ont connaissance.</p>
                </div>

        </main>

        <footer>

            <ul id="texte">
                <li><a href="cookie.php">Cookies</a></li>
                <li ><a href="mention.php">Mention légales</a></li>
                <li ><a href="politique.php">Politique de confidentialité</a></li>
                <li><a href="contacteznous.php">Contactez-nous</a></li>
                <li><a href="plandusite.php">Plan du site</a></li>
                <li>A Poils - @ Copyright 2023</a></li>
            </ul>

        
    </footer>

    </body>

</html>