
<footer>

        <ul id="texte">
            <li><a href="cookie.php">Cookies</a></li>
            <li ><a href="mention.php">Mention légales</a></li>
            <li ><a href="politique.php">Politique de confidentialité</a></li>
            <li><a href="contacteznous.php">Contactez-nous</a></li>
            <li><a href="plandusite.php">Plan du site</a></li>
            <li>A Poils - @ Copyright 2023</a></li>
        </ul>

    
</footer>




            

            
