var images = ["images/race_slides.jpg", "images/chiens_fav.jpg", "images/annonce.jpg"];
var index = 0;
    
function Previous() {
    // Décrémenter l'index pour passer à l'image précédente
    index--;

    // Si on arrive au début du tableau, aller à la fin
    if (index < 0) {
        index = images.length - 1;
}

    // Afficher la nouvelle image
    document.getElementById("image-annonce").src = images[index];
}  

function Next() { 
    // Incrémenter l'index pour passer à l'image suivante
    index++;

    // Si on arrive à la fin du tableau, aller au début
    if (index >= images.length) {
        index = 0;
    }                   
    // Afficher la nouvelle image
    document.getElementById("image-annonce").src = images[index];
}