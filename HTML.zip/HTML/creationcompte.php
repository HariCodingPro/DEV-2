<!DOCTYPE html>
<html>
    <head>
        <title>A poils !</title>
        <meta charset="utf-8">
        <link rel="stylesheet" href="./CSS/header.css">
        <link rel="stylesheet" href="./CSS/accueil.css">
        <link rel="stylesheet" href="./CSS/adoptions.css">
        <link rel="stylesheet" href="./CSS/creerannonce.css">
        <link rel="stylesheet" href="./CSS/compte.css">
        <link rel="stylesheet" href="./CSS/moncompte.css">
        <link rel="stylesheet" href="./CSS/apropos.css">
        <link rel="stylesheet" href="./CSS/description.css">
        <link rel="stylesheet" href="./CSS/footer.css">
        <link rel="stylesheet" href="./CSS/liste_description.css">
        <link rel="stylesheet" href="./CSS/contacteznous.css">
        <link rel="stylesheet" href="./CSS/favoris.css">
        <link rel="stylesheet" href="./CSS/pageanimal.css">
        <link rel="stylesheet" href="./CSS/adopter.css">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.13.0/css/all.css"/>
        <link rel="stylesheet" href="https://kit.fontawesome.com/3973c994c7.css" crossorigin="anonymous">
        <script src="JS/header.js"></script>
        <script src="JS/creerannonce.js"></script>
        <script src="JS/connexion.js"></script>

    </head>
    <body>
    <header>
                <div id="menu" name="menu">
                    <input id="fermer_menu" type="button" value="fermer" onclick="derouler()">
                    <ul>
                        <li><a href="index.php"><input class="sidemenu_button" type="button" value="Accueil"></a></li>
                        <li><a href="adoptions.php"><input class="sidemenu_button" type="button" value="Adopter"></a></li>
                        <li><a href="creerannonce.php"><input class="sidemenu_button" type="button" value="Creer mon annonce"></a></li>
                        <li><a href="liste_description.php"><input class="sidemenu_button" type="button" value="Decouvrir nos animaux"></a></li>
                        <li><a href="apropos.php"><input class="sidemenu_button" type="button" value="Qui sommes nous ?"></a></li>
                    </ul>
                </div>

                <div id="gray_bg" name="gray_bg" onclick="derouler()">
                    
                </div>

                <div id="div_bouton_menu" name="div_bouton_menu" onclick="derouler()">
                    <div id="sous_div_menu" name="sous_div_menu">
                        <div id="details" name="details">
                            <div class="explore_but1"></div>
                            <div class="explore_but2"></div>
                            <div class="explore_but3"></div>
                        </div>    
                        <p>Menu</p> 
                    </div>
                </div>
            
                <div id="logo" name="logo">
                    <a href="index.php" title="Aller à l'accueil">
                    <img src="images/logo.jpg" width="100px" height="100%">
                    </a>
                </div>

                <nav id="nav_bar" name="nav_bar">
                    <ul>
                        <li><a href="index.php"><input type="button" value="Accueil" class="nav_explore"></a></li>
                        <li><a href="liste_description.php"><input type="button" value="Nos animaux" class="nav_explore"></a></li>
                        <li><a href="apropos.php"><input type="button" value="A propos" class="nav_explore"></a></li>
                    </ul>
                </nav>

                <div id="fav_cpt" name="fav_cpt">
                    <ul>
                        <li><a style='font-size:24px' class='fa' href="favoris.php" title="Favoris">&#xf004;</a></li> <!--COEUR-->
                        <li><a style='font-size:24px' class='fas' href="compte.php" title="Compte" >&#xf406;</a></li> <!--Bonhomme-->
                    </ul>
                </div>

            </header>

            <div id="images_connexion">
                <h1 style="text-align:center; color:white;">Création de compte</h1>
                <div id="formannonce">
                    <form id="forms"> 
                        <h3>Informations personnelles</h3>

                        <label for="anom">Nom  </label><br>
                        <input type="text" id="anom" name="anom"><br><br>

                        <label for="aprenom">Prénom  </label><br>
                        <input type="text" id="aprenom" name="aprenom"><br><br>

                        <label for="addn">Date de naissance  </label><br>
                        <input type="date" id="addn" name="addn"><br><br>

                        <label for="amail">Mail  </label><br>
                        <input type="text" id="amail" name="amail"><br><br>

                        <label for="atel">Téléphone  </label>
                        <i class="fas fa-phone"></i><br>
                        <input type="text" id="ftel" name="atel"><br><br>

                        <label for="apdi">Pièce d'identité  </label>
                        <i class="fas fa-id-card"></i><br><br>
                        <input type="file" id="fpdi" name="apdi"><br><br>

                        <h3>Informations de connexion</h3>

                        <label for="alogin">Identifiant</label><br>
                        <input type="text"><br><br>

                        <label for="alogin">Mot de passe</label><br>
                        <input type="password"><br><br>

                        <a href="connexion.php" id="un">J'ai déjà un compte</a><br><br><br>

                        <input type="submit" class="submit_co">
                    
                    </form>
                </div>    

            </div>
        
            <footer>

                <ul id="texte">
                    <li><a href="cookie.php">Cookies</a></li>
                    <li ><a href="mention.php">Mention légales</a></li>
                    <li ><a href="politique.php">Politique de confidentialité</a></li>
                    <li><a href="contacteznous.php">Contactez-nous</a></li>
                    <li><a href="plandusite.php">Plan du site</a></li>
                    <li>A Poils - @ Copyright 2023</a></li>
                </ul>


            </footer>
    </body>
</html>
        