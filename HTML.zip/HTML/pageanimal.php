<!DOCTYPE html>
<html>
    <head>
        <title>A poils !</title>
        <meta charset="utf-8">
        <link rel="stylesheet" href="./CSS/header.css">
        <link rel="stylesheet" href="./CSS/accueil.css">
        <link rel="stylesheet" href="./CSS/adoptions.css">
        <link rel="stylesheet" href="./CSS/creerannonce.css">
        <link rel="stylesheet" href="./CSS/compte.css">
        <link rel="stylesheet" href="./CSS/moncompte.css">
        <link rel="stylesheet" href="./CSS/apropos.css">
        <link rel="stylesheet" href="./CSS/description.css">
        <link rel="stylesheet" href="./CSS/footer.css">
        <link rel="stylesheet" href="./CSS/liste_description.css">
        <link rel="stylesheet" href="./CSS/contacteznous.css">
        <link rel="stylesheet" href="./CSS/favoris.css">
        <link rel="stylesheet" href="./CSS/pageanimal.css">
        <link rel="stylesheet" href="./CSS/adopter.css">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.13.0/css/all.css"/>
        <link rel="stylesheet" href="https://kit.fontawesome.com/3973c994c7.css" crossorigin="anonymous">
        <script src="JS/header.js"></script>
        <script src="JS/creerannonce.js"></script>
        <script src="JS/connexion.js"></script>
    </head>

    <body>
            <header>
                <div id="menu" name="menu">
                    <input id="fermer_menu" type="button" value="fermer" onclick="derouler()">
                    <ul>
                        <li><a href="index.php"><input class="sidemenu_button" type="button" value="Accueil"></a></li>
                        <li><a href="adoptions.php"><input class="sidemenu_button" type="button" value="Adopter"></a></li>
                        <li><a href="creerannonce.php"><input class="sidemenu_button" type="button" value="Creer mon annonce"></a></li>
                        <li><a href="liste_description.php"><input class="sidemenu_button" type="button" value="Decouvrir nos animaux"></a></li>
                        <li><a href="apropos.php"><input class="sidemenu_button" type="button" value="Qui sommes nous ?"></a></li>
                    </ul>
                </div>

                <div id="gray_bg" name="gray_bg" onclick="derouler()">
                    
                </div>

                <div id="div_bouton_menu" name="div_bouton_menu" onclick="derouler()">
                    <div id="sous_div_menu" name="sous_div_menu">
                        <div id="details" name="details">
                            <div class="explore_but1"></div>
                            <div class="explore_but2"></div>
                            <div class="explore_but3"></div>
                        </div>    
                        <p>Menu</p> 
                    </div>
                </div>
            
                <div id="logo" name="logo">
                    <a href="index.php" title="Aller à l'accueil">
                    <img src="images/logo.jpg" width="100px" height="100%">
                    </a>
                </div>

                <nav id="nav_bar" name="nav_bar">
                    <ul>
                        <li><a href="index.php"><input type="button" value="Accueil" class="nav_explore"></a></li>
                        <li><a href="liste_description.php"><input type="button" value="Nos animaux" class="nav_explore"></a></li>
                        <li><a href="apropos.php"><input type="button" value="A propos" class="nav_explore"></a></li>
                    </ul>
                </nav>

                <div id="fav_cpt" name="fav_cpt">
                    <ul>
                        <li><a style='font-size:24px' class='fa' href="favoris.php" title="Favoris">&#xf004;</a></li> <!--COEUR-->
                        <li><a style='font-size:24px' class='fas' href="compte.php" title="Compte" >&#xf406;</a></li> <!--Bonhomme-->
                    </ul>
                </div>

            </header>
        <main>
            <div class="contenu-annonce">
                <div class="section-haute">
                    <div class="section-photos">
                        <script src="JS/pageanimal.js"> </script>
                        <div class="img-annonce">
                            <img id="image-annonce" src="images/chiens_fav.jpg">
                        </div>  
                        <div class="arrows_animal"> 
                            <i class="fas fa-arrow-left" onclick="Previous()" style="color: rgb(246, 185, 44);"></i> 
                            <i class="fas fa-arrow-right" onclick="Next()"></i>
                        </div>
                    </div>            

                    <div class="section-haute-droite">
                        <div class="section-description">
                            <ul>
                                <li id="nom_p_animal"> Albert</li><br>
                                <li> 15 ans</li><br>
                                <li> Espèce: Chien</li><br>
                                <li> Race: Labrador</li><br>
                                <li> Caractère: Agréable</li><br>
                                <li> Education: A la dure</li><br>
                             
                            </ul>    
                        </div> 

                        <div class="section-information">
                            <h3> Informations complémentaires</h3>
                            <ul>
                                <li> Particularités physique: Musclé</li><br>
                                <li><a href="description.php"> Histoire de la race</a></li>
                            </ul>
                            <h3> Contacter le donneur </h3>
                            <ul>
                                <li> Portable: 06 60 40 88 55</li><br>
                                <li> Email: laurentlafitte@wanadoo.fr</li>
                            </ul>    
                        </div>
                    </div>    

                </div>
                
                <div class="section-basse">
                    <div class="section-note-animal">
                        <h3> Note sur l'animal </h3>
                            <p> blbla description en phrase de l'animal </p>
                    </div>
                    
                    <div class="section-adopter">  
                        <a href="adopter.php" class="btn"><i class="fa fa-heart">Adopter</i></a>                     
                    </div>   
                </div>

            </div>  
        </main>
        <footer>

            <ul id="texte">
                <li><a href="cookie.php">Cookies</a></li>
                <li ><a href="mention.php">Mention légales</a></li>
                <li ><a href="politique.php">Politique de confidentialité</a></li>
                <li><a href="contacteznous.php">Contactez-nous</a></li>
                <li><a href="plandusite.php">Plan du site</a></li>
                <li>A Poils - @ Copyright 2023</a></li>
            </ul>


        </footer>
    </body>
</html>
            