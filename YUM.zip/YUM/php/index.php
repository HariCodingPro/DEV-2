<!DOCTYPE html>
<html>
	<?php
		include_once("head.php");
	?>
	<head>
		<title>YUM WORLD</title>
	</title>

<body>

	<?php
		include_once("header.php");
	?>


<main>
	<?php
		//include_once("mainMenu.php");
		
	?>
		
	<div class="main-text">	
		<p class="main-content">
			Plat du jour :<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
		</p>

	</div>
</main>

	<?php
		include_once("footer.php");
	?>

</body>

</html>
