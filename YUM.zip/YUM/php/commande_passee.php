<!DOCTYPE html>
<html lang="en">
    <?php
		include_once("head.php");
	?>
    <head>
        <title>Panier</title>
    </head>


<body>
<?php
	include_once("header.php");
?>



<p>Merci pour votre commande !</p>




<?php
    include('footer.php')
?>
</body>

</html>